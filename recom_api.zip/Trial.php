<?php
require_once("dbconn.php");
  $dbconn = new dbconn();
  $conn=$dbconn->return_conn();
// Check connection
if ($conn==NULL) {
    echo 'COnnection Failed';
}
     else
     {
     echo 'COnnection Sucess';
     }

?>
